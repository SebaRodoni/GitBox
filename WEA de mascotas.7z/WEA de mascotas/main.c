#include <stdio.h>
#include <stdlib.h>

typedef struct {
int legajo;
char nombre[20];
int edad;
char tipo[20];
}eMascota;
int main()
{

    eMascota unaMascota;
    eMascota mascota2;
    //eMascota mascotas[3]={{1424,"Pepinio","Canino",13},{6453,"Queen","Felino",1}{0001,"estrangula","Reptil",20}};
    strcpy(unaMascota.tipo, "Roedor");
    unaMascota.edad = 8;
    unaMascota.legajo = 6420;
    strcpy(unaMascota.nombre, "Emmeth");


    strcpy(mascota2.tipo, "Reptil");
    mascota2.edad = 12;
    mascota2.legajo = 0001;
    strcpy(mascota2.nombre, "Estrangula");

    modificarEdad(&unaMascota, 50);

    printf("Legajo= %d          NOMBRE= %s            TIPO= %s         EDAD= %d\n\n", unaMascota.legajo, unaMascota.nombre, unaMascota.tipo, unaMascota.edad);
    printf("Legajo= %d          NOMBRE= %s            TIPO= %s         EDAD= %d\n\n", mascota2.legajo, mascota2.nombre, mascota2.tipo, mascota2.edad);
    return 0;
     //Esto no tiene nada que ver con lo qe hay que hacer pero es para debugear la wea de listas
}


void modificarEdad(eMascota* x, int edad){
x->edad = edad;
}
